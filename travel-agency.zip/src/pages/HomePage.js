// src/pages/HomePage.js
import React, { useState, useEffect } from 'react';
import TourCard from '../components/TourCard';
import FilterMenu from '../components/FilterMenu';
import SortMenu from '../components/SortMenu';
import SearchBar from '../components/SearchBar';
import kutaisiImage1 from '../images/kutaisi1.jpg'; // Import the JPEG image
import tbilisiImage1 from '../images/tbilisi1.jpg';
import tbilisiImage2 from '../images/tbilisi2.jpg';
import batumiImage1 from '../images/batumi1.jpg';
import telaviImage1 from '../images/telavi1.jpg';
import mcxetaImage1 from '../images/mcxeta1.jpg';
import borjomimage1 from '../images/borjomi1.jpg';
import batumiImage2 from '../images/batumi2.jpg';


const HomePage = () => {

  const [selectedDurations, setSelectedDurations] = useState([]);
  const [selectedTimes, setSelectedTimes] = useState([]);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sortCriteria, setSortCriteria] = useState('default');
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  
  const tours = [
    {
      type: 'DAY TRIP',
      title: 'Tbilisi: Mtskheta, Jvari, Gori and Uplistsikhe Day Tour',
      duration: '10',
      price: '$34.00',
      image: mcxetaImage1,
      keyWords: 'tbilisi, mtskheta, jvari, gori, uplistsikhe',
      time: 'morning',
      startDate: '2024-07-01T00:00:00',
    },
    {
      type: 'DAY TRIP',
      title: 'Discover Georgia: Vardzia, Khertvisi, Rabat & Borjomi',
      duration: '13',
      price: '$50.00',
      image: borjomimage1,
      keyWords: 'vardzia, khertvisi, rabat, borjomi',
      time: 'none',
      startDate: '2024-08-01T00:00:00',
    },
    {
      type: 'PRIVATE TOUR',
      title: 'Private tour from KUTAISI: BATUMI and dendrological park',
      duration: '11.5',
      price: '$192.92',
      image: batumiImage2,
      keyWords: 'kutaisi, batumi, dendrological park',
      time: 'morning',
      startDate: '2024-09-01T00:00:00',
    },

    {
      type: 'DAY TRIP',
      title: 'From Tbilisi: Dashbashi canyon,Algeti,Shavnabada Group Tour',
      duration: '8',
      price: '$37.73',
      image: tbilisiImage2,
      keyWords: 'tbilisi, algeti',
      time: 'morning',
      startDate: '2024-09-01T00:00:00',
    },
    {
      type: 'DAY TRIP',
      title: 'From Kutaisi: Guided Tour of Sataplia, Prometheus & Martvili',
      duration: '9',
      price: '$30.01',
      image: kutaisiImage1,
      keyWords: 'kutaisi, sataplia, martvili',
      time: 'morning',
      startDate: '2024-07-01T00:00:00',
    },
    {
      type: 'DAY TRIP',
      title: 'From Tbilisi: Kazbegi, Gudauri & Zhinvali Guided Group Tour',
      duration: '11',
      price: '$23.41',
      image: tbilisiImage1,
      keyWords: 'tbilis, kazbegi, Gudauri, zhinvali',
      time: 'none',
      startDate: '2024-08-01T00:00:00',
    },
    {
      type: 'WATER ACTIVITY',
      title: 'Batumi to Mtirala National park - Half day hiking group tour',
      duration: '4',
      price: '$30.01',
      image: batumiImage1,
      keyWords: 'batumi, mtirala',
      time: 'afternoon',
      startDate: '2024-09-01T00:00:00',
    },
    {
      type: 'DAY TRIP',
      title: 'Kakheti: Bodbe Monastery, Sighnaghi & Telavi Guided Tour',
      duration: '10',
      price: '$23',
      image: telaviImage1,
      keyWords: 'kakheti, bodbe, sighnaghi, telavi',
      time: 'none',
      startDate: '2024-09-01T00:00:00',
    }
  ];

  const parseDuration = (duration) => {
    return parseFloat(duration);
  };

  const getSelectedDurationRange = () => {
    return selectedDurations.map((range) => {
      if (range === 'Full day (7+ hours)') {
        return { min: 7, max: Infinity };
      } else {
        const [min, max] = range.split('-').map((str) => parseFloat(str.trim()));
        return { min, max };
      }
    });
  };

  const filteredTours = tours.filter((tour) => {
    const tourDuration = parseDuration(tour.duration);
    const tourStartDate = new Date(tour.startDate);
    const durationMatch =
      selectedDurations.length === 0 ||
      getSelectedDurationRange().some(
        ({ min, max }) => tourDuration >= min && tourDuration <= max
      );

    const timeMatch =
      selectedTimes.length === 0 ||
      (selectedTimes.includes(tour.time) ||
        (selectedTimes.includes('1 day') && tourDuration >= 7));

    const priceMatch =
      (minPrice === '' || parseFloat(tour.price.replace('$', '')) >= parseFloat(minPrice)) &&
      (maxPrice === '' || parseFloat(tour.price.replace('$', '')) <= parseFloat(maxPrice));

    const dateMatch =
      (!startDate || tourStartDate >= startDate) &&
      (!endDate || tourStartDate <= endDate);

    const queryMatch =
      searchQuery === '' ||
      tour.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tour.keyWords.toLowerCase().includes(searchQuery.toLowerCase());

    return durationMatch && timeMatch && priceMatch && dateMatch && queryMatch;
  });

  const sortedTours = filteredTours.sort((a, b) => {
    const priceA = parseFloat(a.price.replace('$', ''));
    const priceB = parseFloat(b.price.replace('$', ''));
    const dateA = new Date(a.startDate);
    const dateB = new Date(b.startDate);

    switch (sortCriteria) {
      case 'priceLowHigh':
        return priceA - priceB;
      case 'priceHighLow':
        return priceB - priceA;
      case 'dateAscending':
        return dateA - dateB;
      case 'dateDescending':
        return dateB - dateA;
      default:
        return 0;
    }
  });

  return (
    <div className='HomePageContainer'>
      <SearchBar
        setSearchQuery={setSearchQuery}
        setStartDate={setStartDate}
        setEndDate={setEndDate}
      />
      <FilterMenu
        selectedDurations={selectedDurations}
        setSelectedDurations={setSelectedDurations}
        selectedTimes={selectedTimes}
        setSelectedTimes={setSelectedTimes}
        minPrice={minPrice}
        setMinPrice={setMinPrice}
        maxPrice={maxPrice}
        setMaxPrice={setMaxPrice}
      />
      <SortMenu setSortCriteria={setSortCriteria} />
      <div className="tour-gallery">
        {sortedTours.map((tour, index) => (
          <TourCard
            key={index}
            type={tour.type}
            title={tour.title}
            duration={tour.duration}
            price={tour.price}
            image={tour.image}
            description={tour.description}
            time={tour.time}
            startDate={tour.startDate}
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;