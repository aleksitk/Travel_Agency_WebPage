import React from 'react';
import '../registration/style.css';
import facebook from '../registration/facebook.png';
import twitter from '../registration/twitter.png';
import linkedin from '../registration/linkedin.png';

const Contact = () => {
  return (
    <div className="wrapper">
      <div className="title">
        Contact Us
      </div>
      <form action="#">
        <div className="field">
          <input type="text" required />
          <label>Full Name</label>
        </div>
        <div className="field">
          <input type="email" required />
          <label>Email Address</label>
        </div>
        <div className="field">
          <textarea required />
          <label>Your Message</label>
        </div>
        <div className="field">
          <input type="submit" value="Send Message" style={{marginTop:'40px'}}/>
        </div>
        <div className='sources' style={{marginTop: '57px'}}>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
            <img src={facebook} alt="Facebook" />
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
            <img src={twitter} alt="Twitter" />
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            <img src={linkedin} alt="LinkedIn" />
          </a>
        </div>
      </form>
    </div>
  );
};

export default Contact;
