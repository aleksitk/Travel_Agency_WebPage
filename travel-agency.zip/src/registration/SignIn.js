import React from 'react';
import './style.css';
import facebook from './facebook.png'
import twitter from './twitter.png'
import linkedin from './linkedin.png'
const SignIn = () => {
  return (
    <div className="wrapper">
      <div className="title">
        Login Form
      </div>
      <form action="#">
        <div className="field">
          <input type="text" required value={""}/>
          <label>Email Address</label>
        </div>
        <div className="field">
          <input type="password" required value={''}/>
          <label>Password</label>
        </div>
        <div className="content">
          <div className="checkbox">
            <input type="checkbox" id="remember-me" />
            <label htmlFor="remember-me">Remember me</label>
          </div>
          <div className="pass-link">
            <a href="#">Forgot password?</a>
          </div>
        </div>
        <div className="field">
          <input type="submit" value="Login" />
        </div>
        <div className="signup-link">
          Not a member? <a href="/signup">Signup now</a>
        </div>
        <div className='sources'>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                <img src={facebook} alt="Facebook" />
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
                <img src={twitter} alt="Twitter" />
            </a>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                <img src={linkedin} alt="LinkedIn" />
            </a>
        </div>
      </form>
    </div>
  );
};

export default SignIn;
