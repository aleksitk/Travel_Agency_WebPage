import React from 'react';
import facebook from './facebook.png'
import twitter from './twitter.png'
import linkedin from './linkedin.png'
import './style.css';

const SignUp = () => {
  return (
    <div className="wrapper">
      <div className="title">
        Signup Form
      </div>
      <form action="#">
        <div className="field">
          <input type="text" required />
          <label>Username</label>
        </div>
        <div className="field">
          <input type="email" required />
          <label>Email Address</label>
        </div>
        <div className="field">
          <input type="password" required />
          <label>Password</label>
        </div>
        <div className="field">
          <input type="submit" value="Signup" />
        </div>
        <div className="signin-link">
          Already a member? <a href="/signin">Sign in now</a>
        </div>
        <div className='sources'>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                <img src={facebook} alt="Facebook" />
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
                <img src={twitter} alt="Twitter" />
            </a>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                <img src={linkedin} alt="LinkedIn" />
            </a>
        </div>
      </form>
    </div>
  );
};

export default SignUp;
