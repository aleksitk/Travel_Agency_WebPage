// src/components/SearchBar.js
import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const SearchBar = ({ setSearchQuery, setStartDate, setEndDate }) => {
  const [query, setQuery] = useState('');
  const [start, setStart] = useState(null);
  const [end, setEnd] = useState(null);

  const handleSearch = () => {
    setSearchQuery(query);
    setStartDate(start);
    setEndDate(end);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="search-bar-container">
      <div className="search-bar">
        <input 
          type="text" 
          value={query} 
          onChange={(e) => setQuery(e.target.value)} 
          placeholder="Search tours..." 
          onKeyPress={handleKeyPress}
        />
        <button onClick={handleSearch} className="search-button">
          <svg width="24" height="24" viewBox="0 0 24 24">
            <path d="M21.53 20.47l-5.79-5.79A7.93 7.93 0 0 0 18 10 8 8 0 1 0 10 18a7.93 7.93 0 0 0 4.68-1.25l5.79 5.79a.75.75 0 0 0 1.06-1.06zM10 16a6 6 0 1 1 6-6 6 6 0 0 1-6 6z" />
          </svg>
        </button>
      </div>
      <div className="date-pickers">
        <div className="date-picker">
          <DatePicker
            selected={start}
            onChange={date => setStart(date)}
            selectsStart
            startDate={start}
            endDate={end}
            placeholderText="Start Date"
          />
          <svg className="calendar-icon" width="24" height="24" viewBox="0 0 24 24">
            <path d="M7 10h5v5H7zM7 2h5v5H7zM2 7h5v5H2zM12 7h5v5h-5zM7 12h5v5H7zM7 7h5v5H7z" />
          </svg>
        </div>
        <div className="date-picker">
          <DatePicker
            selected={end}
            onChange={date => setEnd(date)}
            selectsEnd
            startDate={start}
            endDate={end}
            minDate={start}
            placeholderText="End Date"
          />
          <svg className="calendar-icon" width="24" height="24" viewBox="0 0 24 24">
            <path d="M7 10h5v5H7zM7 2h5v5H7zM2 7h5v5H2zM12 7h5v5h-5zM7 12h5v5H7zM7 7h5v5H7z" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
