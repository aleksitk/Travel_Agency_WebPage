// src/components/SortMenu.js
import React, { useState } from 'react';

const SortMenu = ({ setSortCriteria }) => {
  const [selectedSort, setSelectedSort] = useState('default');

  const handleSortChange = (event) => {
    setSelectedSort(event.target.value);
    setSortCriteria(event.target.value);
  };

  return (
    <div className="sort-menu">
      <p style={{fontSize: "16px", color: '#63687a', fontStyle: 'normal'}}>8 activities found</p>
      <div className="sort-dropdown">
        <select value={selectedSort} onChange={handleSortChange}>
          <option value="default">Recommended</option>
          <option value="priceLowHigh">Price - Low to High</option>
          <option value="priceHighLow">Price - High to Low</option>
          <option value="dateAscending">Date - Ascending</option>
          <option value="dateDescending">Date - Descending</option>
        </select>
      </div>
    </div>
  );
};

export default SortMenu;
