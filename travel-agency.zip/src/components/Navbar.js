import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      <ul>
        <li id='homePos'><Link to="/">Home</Link></li>
        <div className='titleRightPosition'>
          <li><Link to="/contact">Contact</Link></li>
          <li className="profile-container">
            <a href='#' className="underline">Profile</a>
            <div className="dropdown-content">
              <Link to="/signup">Log in or sign up</Link>
              <a href="#">Change Appearance</a>
              <a href="#">Change Language</a>
            </div>
          </li>
        </div>
      </ul>
    </nav>
  );
};

export default Navbar;
