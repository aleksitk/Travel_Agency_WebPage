import React, { useState } from 'react';

const FilterMenu = ({
  selectedDurations,
  setSelectedDurations,
  selectedTimes,
  setSelectedTimes,
  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice
}) => {
  const [isDurationOpen, setIsDurationOpen] = useState(false);
  const [isTimeOpen, setIsTimeOpen] = useState(false);
  const [isPriceOpen, setIsPriceOpen] = useState(false);

  const toggleDurationDropdown = () => {
    setIsDurationOpen(!isDurationOpen);
  };

  const toggleTimeDropdown = () => {
    setIsTimeOpen(!isTimeOpen);
  };

  const togglePriceDropdown = () => {
    setIsPriceOpen(!isPriceOpen);
  };

  const handleDurationChange = (event) => {
    const { value, checked } = event.target;
    
    if (value === '2 days' || value === '3 days') {
      setSelectedTimes((prev) =>
        checked ? [...prev, '1 day'] : prev.filter((option) => option !== '1 day')
      );
    }
    
    setSelectedDurations((prev) =>
      checked ? [...prev, value] : prev.filter((option) => option !== value)
    );
  };

  const handleTimeChange = (event) => {
    const { value, checked } = event.target;
    setSelectedTimes((prev) =>
      checked ? [...prev, value] : prev.filter((option) => option !== value)
    );
  };

  return (
    <div className="filter-menu">
      <div className="dropdown">
        <div className="dropdown-header" onClick={toggleDurationDropdown}>
          {selectedDurations.length > 0
            ? `${selectedDurations.join(', ')}`
            : 'Select Duration'}
          <span className="arrow"></span>
        </div>
        {isDurationOpen && (
          <div className="dropdown-body">
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="0-3 hours"
                checked={selectedDurations.includes('0-3 hours')}
                onChange={handleDurationChange}
              />
              0-3 hours
            </label>
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="3-5 hours"
                checked={selectedDurations.includes('3-5 hours')}
                onChange={handleDurationChange}
              />
              3-5 hours
            </label>
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="5-7 hours"
                checked={selectedDurations.includes('5-7 hours')}
                onChange={handleDurationChange}
              />
              5-7 hours
            </label>
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="Full day (7+ hours)"
                checked={selectedDurations.includes('Full day (7+ hours)')}
                onChange={handleDurationChange}
              />
              Full day (7+ hours)
            </label>
          </div>
        )}
      </div>
      <div className="dropdown">
        <div className="dropdown-header" onClick={toggleTimeDropdown}>
          {selectedTimes.length > 0
            ? `${selectedTimes.join(', ')}`
            : 'Select Time'}
          <span className="arrow"></span>
        </div>
        {isTimeOpen && (
          <div className="dropdown-body">
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="morning"
                checked={selectedTimes.includes('morning')}
                onChange={handleTimeChange}
              />
              Morning
            </label>
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="afternoon"
                checked={selectedTimes.includes('afternoon')}
                onChange={handleTimeChange}
              />
              Afternoon
            </label>
            <label className="dropdown-option">
              <input
                type="checkbox"
                value="evening"
                checked={selectedTimes.includes('evening')}
                onChange={handleTimeChange}
              />
              Evening
            </label>
          </div>
        )}
      </div>
      <div className="dropdown">
        <div className="dropdown-header" onClick={togglePriceDropdown}>
          {minPrice && maxPrice
            ? `Price: $${minPrice} - $${maxPrice}`
            : 'Select Price'}
          <span className="arrow"></span>
        </div>
        {isPriceOpen && (
          <div className="dropdown-body">
            <label className="dropdown-option" style={{padding: '8px 10px'}}>
              Min Price: $
              <input
                type="text"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                placeholder="Min"
              />
            </label>
            <label className="dropdown-option" style={{padding: '8px 10px'}}>
              Max Price: $
              <input
                type="text"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                placeholder="Max"
              />
            </label>
          </div>
        )}
      </div>
    </div>
  );
};

export default FilterMenu;
