import React, { useState } from 'react';

const TourCard = ({ title, price, startDate, image, type, duration, time, keyWords }) => {


  return (
    <div className="tour-card">
      <div className="image-container">
        <img src={image} alt={title} className="tour-image" />
      </div>
      <div className='smallDescr'>
        <div className='upperDescr'>
      <p style={{color: '#63687a', fontSize: '14px'}}>{type}</p>
      <p style={{color: '#1a2b49', fontSize: '18px'}}>{title}</p>
      <p style={{color: '#1a2b49', fontSize: '14px'}}>{duration} hours</p>
      </div>
      <div className='downDescr'>
      <p style={{color: '#1a2b49', fontSize: '16px'}}>From {price} <span style={{fontSize: '14px'}}>For person</span></p>
      </div>
      </div>
    </div>
  );
};

export default TourCard;
